
async function load_resume(){
  try{
    const res = await fetch('resume_data.json');
    const data = await res.json();
    document.querySelector('#hero_name').textContent = data.name;
    document.querySelector('#hero_tag').textContent = data.tagline;
    document.querySelector('#bio_text').textContent = data.bio;
    document.querySelector('#contact_email').textContent = data.email;
    document.querySelector('#contact_email').setAttribute('href', 'mailto:'+data.email);
    document.querySelector('#contact_phone').textContent = data.phone;
    document.querySelector('#contact_instagram').setAttribute('href', 'https://instagram.com/'+data.instagram);
    document.querySelector('#contact_instagram').textContent = '@' + data.instagram;

    const hlist = document.querySelector('#highlight_list');
    data.highlights.forEach(t => {
      const li = document.createElement('li');
      li.textContent = t;
      hlist.appendChild(li);
    });

    const exp = document.querySelector('#experience_list');
    data.experience.forEach(item => {
      const wrap = document.createElement('div');
      wrap.className = 'card';
      wrap.innerHTML = `<h4>${item.role} · ${item.org}</h4>
        <p>${item.dates}</p>
        <ul class="list">${item.bullets.map(b=>`<li>${b}</li>`).join('')}</ul>`;
      exp.appendChild(wrap);
    });

    const train = document.querySelector('#training_list');
    data.training.forEach(t => {
      const li = document.createElement('li');
      li.textContent = t;
      train.appendChild(li);
    });

    const credits = document.querySelector('#credits_list');
    data.credits.forEach(t => {
      const li = document.createElement('li');
      li.textContent = t;
      credits.appendChild(li);
    });

  }catch(e){
    console.error(e);
  }
}

function setup_gallery(){
  // Add image file names to this array or drop images into assets_images and list them here
  const files = ['placeholder1.jpg','placeholder2.jpg','placeholder3.jpg','placeholder4.jpg'];
  const grid = document.querySelector('#gallery_grid');
  files.forEach(name => {
    const path = 'assets_images/'+name;
    const img = document.createElement('img');
    img.src = path;
    img.alt = 'Gallery photo';
    grid.appendChild(img);
  });
}

document.addEventListener('DOMContentLoaded', () => {
  load_resume();
  setup_gallery();
});
