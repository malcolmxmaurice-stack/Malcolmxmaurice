
Malcolm Dance Site

How to use
1. Open resume_data.json and replace the sample content with your real resume details.
2. Replace the iframe on the home section with a link to one of your Instagram reels or a class trailer on YouTube or Vimeo.
3. Drop photos into assets_images and list their file names in assets_js/main.js inside setup_gallery().
4. Update the contact form action URL with your Formspree endpoint or your backend route.
5. Deploy to Netlify Vercel or GitHub Pages. This is a static site and needs no server.

Notes about Instagram
Instagram official feeds need an access token or per post embeds. Quick options
• Paste single post embed codes into the media areas
• Use a third party widget service if you prefer a dynamic grid

No hyphens were used in class names or file names.
